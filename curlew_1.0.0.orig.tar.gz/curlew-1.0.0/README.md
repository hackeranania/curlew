$dpkg -i package 

suggestion if you use the gdebi package


install it using apt like
$ sudo apt install gdebi
# Then 
sudo gdebi curlew.deb 

curlew is the easiest subdomain finder you ever seen
if you prefer to just see the subdomains for the specific  url use 

$ curlew -u https://www.google.com  #then it print the sub domains founded


if you want to output the file use the -o argument like
$ curlew -u https://www.google.com  -o yourfilename


or set the time out use the -t argument like 


$ curlew -u https://www.google.com -t 1

default is 1


if you want to make fast search use the -B command to set the urls to fetch in it 
like 
$ curlew -u https://www.google.com  -B 100
-B have only 100,500,800,1000,10000

to see more visit our github page
https://www.github.com/hackeranania